// Check it is possible to load and run the exported members
var nr = require('..') ;
nr.$asyncbind() ;
nr.$asyncspawn() ;
